def hello():
    print("Hello from knowledge-map!")